## BAIXAR SWITCH :link: [v1.0](https://drive.google.com/file/d/1jlmQR_Nv6MmxRzU9-RVeppFOHmSz4MKJ/view?usp=sharing)

<h1 align="center"><figure>
  <img src="Crisis3.png">
</figure></h1>

## :small_blue_diamond:Sobre a Tradução.

Tradução feita pelo grupo TriboGamer.

_ "Portado para Nintendo Switch por Traduções GBJ" _

## :small_blue_diamond:Por quê?

Este projeto irá ajudar muitas pessoas a entender melhor a história do jogo, portanto ficarei feliz se você puder ajudar de alguma forma o projeto, tradução, erros ortográficos e revisão em jogo!

## :small_blue_diamond:Requerimentos

- Nintendo Switch Debloqueado - SXOS ou ATMOSPHERE>

## :small_blue_diamond:Instalação

**SXOS** Basta colocar a pasta ```0100CD3010AE2000``` no caminho ```sxos\titles``` para quem usa esse desbloqueio e reiniciar o desbloqueio.
**ATMOSPHERE** Basta colocar a pasta ```0100CD3010AE2000``` no caminho ```Atmosphere\Contents``` para quem usa esse desbloqueio

## :small_blue_diamond:Ferramentas Ultilizadas

:link: [Visual Studio Code](https://code.visualstudio.com)
:link: [Excel 2016](https://www.office.com/?omkt=pt-br)

## :small_blue_diamond:Doações

[![Picpay](https://i.ibb.co/cYcsCnZ/hhhh.png)](https://picpay.me/gilsongbj)

Obrigado!:wave:
